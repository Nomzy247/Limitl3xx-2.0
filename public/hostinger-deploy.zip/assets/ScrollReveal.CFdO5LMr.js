import{j as s}from"./index.C262jYCk.js";function l({children:r}){return s.jsx("div",{className:"w-full",children:r})}export{l as S};
