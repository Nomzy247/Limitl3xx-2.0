import{j as s}from"./index.DiHk8p00.js";function l({children:r}){return s.jsx("div",{className:"w-full",children:r})}export{l as S};
