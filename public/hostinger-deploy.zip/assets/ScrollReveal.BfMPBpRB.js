import{j as s}from"./index.Cq8zo2Pv.js";function l({children:r}){return s.jsx("div",{className:"w-full",children:r})}export{l as S};
